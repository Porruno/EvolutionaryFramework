/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Lay
 */
public class main {
    public static void main(String[] args){
        //GroupOfTestsSosa2011.main(null);
        //GroupOfTestsChoosingName.main(null);      
        GroupOfTestsCSP.main(null);
    }   
}