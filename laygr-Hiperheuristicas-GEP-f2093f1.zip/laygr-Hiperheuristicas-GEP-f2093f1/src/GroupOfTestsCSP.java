
import CSP.tests.test1.CSPTestGEPCoevolutive;
import CSP.tests.test1.CSPTestGPCoevolutive;
import test.GroupOfTests;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Lay
 */
public class GroupOfTestsCSP {
    
    public static void main(String[] args){
        GroupOfTests cspTests = new GroupOfTests("CSP", new Class<?>[]{CSPTestGPCoevolutive.class, CSPTestGEPCoevolutive.class}, 1);
        cspTests.graph();
        cspTests.getTestResultAtIndex(0).getBestGenomeOfAllRuns().graph("csp", null);
    }
    
}
