package geneExpressionProgramming;

import geneticAlgorithm.GADelegate;
import geneticAlgorithm.GeneticAlgorithm;

public class GeneExpressionProgramming extends GeneticAlgorithm{

	public GeneExpressionProgramming(GADelegate gaDelegate) {
		super(gaDelegate);
	}

}
