/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package geneticAlgorithm.Utility;

/**
 *
 * @author Lay
 */
public class ObjectNumber {
    public Object object;
    public double number;
    
    public ObjectNumber(Object object, double number){
        this.object = object;
        this.number = number;
    }
}
