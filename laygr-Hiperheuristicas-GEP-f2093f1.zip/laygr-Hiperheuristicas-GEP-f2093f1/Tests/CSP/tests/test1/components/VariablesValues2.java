/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CSP.tests.test1.components;

/**
 *
 * @author Lay
 */
public class VariablesValues2 {
    double[][] values;
    
    public VariablesValues2(double[][] values){
        this.values = values;
    }
    
}