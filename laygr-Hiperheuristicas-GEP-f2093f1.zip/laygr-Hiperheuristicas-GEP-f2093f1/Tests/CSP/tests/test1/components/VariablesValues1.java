/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CSP.tests.test1.components;

/**
 *
 * 
 * @author Jesús Irais González Romero
 */
public class VariablesValues1 {
    double[] values;
    
    public VariablesValues1(double[] values){
        this.values = values;
    }
}
