/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package nombreIdeal.adf;

import grammar.adf.ADFDelegate;

/**
 *
 * @author Lay
 */
public class ADFDelegate_Coevolutive extends ADFDelegate{

    @Override
    public ADFType getADFType() {
        return ADFType.COEVOLUTIVE;
    }
    
}
