package koza1994;

import grammar.adf.ADFDelegate;

public class ADF1DelegateSemicoevolutive extends ADFDelegate {

	@Override
	public ADFType getADFType() {
		return ADFType.SEMICOEVOLUTIVE;
	}

}
